-- PMIS upgrade preflight v0.15.8
-- SAFE BY DESIGN: this file DOES NOT mutate the existing database.
-- Run it on the CURRENT Supabase database and return/export the result before generating the real upgrade migration.

select current_database() database_name,current_user database_user,now() checked_at;
select extname,extversion from pg_extension where extname in ('pgcrypto','uuid-ossp') order by extname;

select table_name from information_schema.tables where table_schema='public' order by table_name;

select table_name,column_name,data_type,is_nullable,column_default
from information_schema.columns
where table_schema='public'
order by table_name,ordinal_position;

select tc.table_name,tc.constraint_name,tc.constraint_type,kcu.column_name,
       ccu.table_name as foreign_table_name,ccu.column_name as foreign_column_name
from information_schema.table_constraints tc
left join information_schema.key_column_usage kcu on tc.constraint_name=kcu.constraint_name and tc.table_schema=kcu.table_schema
left join information_schema.constraint_column_usage ccu on tc.constraint_name=ccu.constraint_name and tc.table_schema=ccu.table_schema
where tc.table_schema='public'
order by tc.table_name,tc.constraint_type,tc.constraint_name;

select schemaname,tablename,indexname,indexdef from pg_indexes where schemaname='public' order by tablename,indexname;

select n.nspname schema_name,p.proname function_name,pg_get_function_identity_arguments(p.oid) arguments,pg_get_functiondef(p.oid) definition
from pg_proc p join pg_namespace n on n.oid=p.pronamespace
where n.nspname='public' and p.proname in ('pmis_login_verify','pmis_set_updated_at')
order by p.proname;

select c.relname table_name,c.relrowsecurity rls_enabled,c.relforcerowsecurity rls_forced
from pg_class c join pg_namespace n on n.oid=c.relnamespace
where n.nspname='public' and c.relkind='r' order by c.relname;

select schemaname,tablename,policyname,permissive,roles,cmd,qual,with_check
from pg_policies where schemaname='public' order by tablename,policyname;

-- Critical compatibility checks
select 'projects.project_status' check_name,case when exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='project_status') then 'PASS' else 'MISSING' end result
union all select 'projects.status_legacy',case when exists(select 1 from information_schema.columns where table_schema='public' and table_name='projects' and column_name='status') then 'PRESENT' else 'ABSENT' end
union all select 'pmis_login_verify',case when to_regprocedure('public.pmis_login_verify(text,text)') is null then 'MISSING' else 'PASS' end;
